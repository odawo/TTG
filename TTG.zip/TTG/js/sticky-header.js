// JavaScript Document
 
  jQuery(document).ready(function(){
  	"use strict";
	 alert("sss");
	 if( jQuery( window ).width() >= "768" ) {
		 
		jQuery(".header-menubar").sticky({topSpacing:0});	
    }

  });
  